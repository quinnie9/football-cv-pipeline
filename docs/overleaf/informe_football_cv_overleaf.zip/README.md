# Tu parte del artículo IEEE (Overleaf)

Secciones incluidas en `main.tex`:

1. **Metodología**
2. **Tecnologías y procesos descartados**
3. **Resultados**
4. **Limitaciones**
5. **Trabajo futuro y mejoras**
6. **Aplicaciones en la industria**

Abstract, intro y estado del arte → tus compañeros en el Overleaf compartido.

## Cómo usarlo

**Opción A — Proyecto solo tuyo**  
Upload `informe_football_cv_overleaf.zip` → compilá pdfLaTeX → exportá PDF o copiá secciones al doc del grupo.

**Opción B — Pegar en el Overleaf del grupo**  
Abrí el `main.tex` compartido del equipo y pegá desde `\section{Metodología}` hasta antes de `\begin{thebibliography}` (o fusioná bibliografía).

## ZIP

```bash
cd docs/overleaf
zip -r informe_football_cv_overleaf.zip main.tex README.md
```

## Videos citados

https://github.com/quinnie9/football-cv-pipeline/releases/tag/demo-v2
